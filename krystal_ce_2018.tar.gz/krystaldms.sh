echo "Starting KRYSTAL DMS - Community Edition 2018 ..."
nohup java -Xmx512M -classpath "./lib/*" com.primeleaf.krystal.KRYSTALServer &
echo "KRYSTAL DMS - Community Edition Started ..."
